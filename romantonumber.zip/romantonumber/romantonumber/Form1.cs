﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace romantonumber
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string roman = textBox1.Text + " ";
            double number = 0;
            for(int i=0;i<roman.Length;i=i+1)
            {
                double add = 0;
                if(roman[i]=='I')
                {
                    if (roman[i + 1] == 'V') { i = i + 1;add = 4; }
                    else if (roman[i + 1] == 'X') { i = i + 1; add = 9; }
                    else { add = 1; }
                }
                else if (roman[i] == 'V') { add = 5; }
                if (roman[i] == 'X')
                {
                    if (roman[i + 1] == 'L') { i = i + 1; add = 40; }
                    else if (roman[i + 1] == 'C') { i = i + 1; add = 90; }
                    else { add = 10; }
                }
                if (roman[i] == 'C')
                {
                    if (roman[i + 1] == 'D') { i = i + 1; add = 400; }
                    else if (roman[i + 1] == 'M') { i = i + 1; add = 900; }
                    else { add = 100; }
                }
                else if(roman[i]=='D')
                {
                    add = 500;
                }
                else if (roman[i] == 'M')
                {
                    add = 1000;
                }
                number = number + add;
            }
            MessageBox.Show(number + "");
        }
    }
}
